IR RGB Controller - A.G.

The 'IRremote' library can be found and installed from Arduino's list of libraries or it can be manually installed using the provided copy in this directory: "..libraries/"


Within this directory you should find two different versions of 'IR RGB Controller'

ver 1.1a:     This is the initial version you had.
ver 1.4.1b:   This is the current version you have. 

Each version should have one '.ino' file. This is the main sketch file that can be compiled and uploaded.
All of the logic and sequence of event can be found within the '.ino' file.
Core, source, and other files can be found in their respective sub-directories

*The 'IRremote' library was NOT developed by me*